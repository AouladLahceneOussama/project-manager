<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Details de la case')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="mb-6 space-x-8">
                <span class="px-6 py-3 font-bold text-center text-white uppercase align-middle transition-all border-0 rounded-lg cursor-pointer active:opacity-85 hover:shadow-soft-xs leading-pro text-xs ease-soft-in tracking-tight-soft shadow-soft-md bg-150 bg-x-25 bg-gray-700 hover:border-slate-700 hover:bg-slate-700 hover:text-white">
                    <?php echo e(__('Total')); ?> : <?php echo e($category->total); ?> DH
                </span>
            </div>
            <div class="bg-white py-4 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

                    <div class="w-full py-2 px-8 h-full overflow-y-auto">

                        <div class="w-full mb-3">
                            <span class="text-gray-400 text-xs "><?php echo e(__('Detail de la case')); ?></span>
                            <div class="bg-gray-200 w-full h-px"></div>
                        </div>


                        <div class="w-full flex mb-2">
                            <p class="text-md rounded-lg bg-white bg-clip-padding  font-semibold text-gray-900">
                                <?php echo e(__('Titre')); ?> :
                            </p>
                            <p class="text-md rounded-lg bg-white bg-clip-padding px-3 font-normal text-gray-700">
                                <?php echo e($category->title); ?>

                            </p>
                        </div>

                        <div class="w-full flex  mb-2">
                            <p class="text-md rounded-lg bg-white bg-clip-padding  font-semibold text-gray-900">
                                <?php echo e(__('Description')); ?> :
                            </p>
                            <p class="text-md rounded-lg bg-white bg-clip-padding px-3 font-normal text-gray-700">
                                <?php echo e($category->description); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <?php if($category->subcategories->count() >0): ?>
            <div class="flex justify-between items-start flex-wrap mt-8">

                <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="my-4" style="width:48%">
                    <div class="mb-6">
                        <span class="px-6 py-3 font-bold text-center text-white uppercase align-middle border-0 rounded-lg text-xs bg-gray-700">
                            <?php echo e(__('Total')); ?> : <?php echo e($sub->total); ?> DH
                        </span>
                    </div>
                    <div class="bg-white shadow-sm rounded-lg p-4 sm:px-6 lg:px-8">
                        <p class="text-md uppercase rounded-lg bg-white px-3 font-semibold text-gray-800">
                            <?php echo e($sub->title); ?>

                        </p>

                        <p class="text-md rounded-lg bg-white px-3 font-normal text-gray-500">
                            Description : <?php echo e($sub->description); ?>

                        </p>

                        <div class="w-full mt-3 px-3">
                            <span class="text-gray-400 text-xs "><?php echo e(__('Details des factures')); ?></span>
                            <div class="bg-gray-200 w-full h-px"></div>
                        </div>

                        <div class="mt-4">
                            <?php $__currentLoopData = $sub->billings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $belling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="my-3 flex justify-between items-center px-3">
                                <div class="flex justify-start items-start space-x-5">
                                    <div>
                                      <p class="text-sm"><?php echo e($belling->title); ?> </p>
                                    <p class="text-sm text-gray-400"><?php echo e($belling->info); ?> </p>     
                                    </div>
                                     <p class="font-bold text-sm"><?php echo e($belling->total); ?> DH</p>
                                </div>
                                
                                <?php if(Auth::user()->is_admin == 1): ?>
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('remark-input', ['belling' => $belling])->html();
} elseif ($_instance->childHasBeenRendered($subcategories->id.'_'.$belling->id)) {
    $componentId = $_instance->getRenderedChildComponentId($subcategories->id.'_'.$belling->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($subcategories->id.'_'.$belling->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($subcategories->id.'_'.$belling->id);
} else {
    $response = \Livewire\Livewire::mount('remark-input', ['belling' => $belling]);
    $html = $response->html();
    $_instance->logRenderedChild($subcategories->id.'_'.$belling->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                <?php else: ?>
                                <?php if($belling->remark != ''): ?>
                                <span class="text-xs block appearance-none rounded-md bg-red-600 px-8 py-2 text-white font-bold"><?php echo e($belling->remark); ?></span>
                                <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <?php if(!$loop->last): ?>
                            <div class="flex justify-center">
                                <div class="bg-gray-200 w-5/6 h-px"></div>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>


                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <?php endif; ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\Info-Penguin\Desktop\project-manager-app\resources\views/category/details.blade.php ENDPATH**/ ?>