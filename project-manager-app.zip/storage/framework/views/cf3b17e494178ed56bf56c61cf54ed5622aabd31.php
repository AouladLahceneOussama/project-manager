<div x-data="{ open:false }" class="bg-white overflow-hidden shadow-sm sm:rounded-lg my-4 p-6">
    <div x-data="{ edit: <?php if ((object) ('showEdit') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('showEdit'->value()); ?>')<?php echo e('showEdit'->hasModifier('defer') ? '.defer' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('showEdit'); ?>')<?php endif; ?>.defer }" class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="w-full flex justify-between items-center mb-2">

            <!-- show folder name -->
            <div x-show="!edit">
                <span>
                    <?php echo e($folder->name); ?>

                </span>

                <span class="text-gray-700 text-xs">
                    ( <?php echo e($folder->archives()->count()); ?> )
                </span>
            </div>

            <!-- edit folder name -->
            <div class="w-1/2 flex justify-start items-center space-x-2" x-show="edit">
                <input type="text" wire:model.lazy="newFolderName" value="<?php echo e($folder->name); ?>" class="text-sm w-full appearance-none rounded-lg border border-solid border-gray-300 bg-white px-3 py-2 font-normal text-gray-700 transition-all focus:border-gray-500 focus:outline-none focus:transition-shadow">
                <?php if(session()->has('message')): ?> <span class="text-gray-400 text-xs"><?php echo e(session('message')); ?></span><?php endif; ?>
            </div>

            <div class="flex justify-center items-center">
                <i @click="edit = !edit" class="fa-solid fa-pen text-green-500 px-2 cursor-pointer text-xs"></i>
                <form wire:submit.prevent="deleteFolder">
                    <?php echo csrf_field(); ?>
                    <button onclick="return confirm('Etes-vous sur de supprimer cette element?')"><i class="fa-solid fa-trash text-red-500 p-1 cursor-pointer text-xs"></i></button>
                </form>
                <i wire:click="getArchives" @click="open = !open" class="fa-solid fa-square-caret-down text-gray-700 px-2 cursor-pointer text-sm"></i>
            </div>

        </div>

        <div x-show="open" class="mt-4 pt-4 border-t-2 border-gray-50">
            <?php $__empty_1 = true; $__currentLoopData = $archives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="flex justify-between items-center px-4">
                <div>
                    <p class="mb-0 leading-tight text-xs text-slate-700">
                        <?php echo e($archive->original_name); ?> <span class="text-xs text-gray-500"> ( <?php echo e($archive->type); ?> )</span>
                    </p>
                </div>

                <div class="flex justify-center items-center">
                    <a href="<?php echo e(Storage::disk('public')->url($archive->path)); ?>" download>
                        <i class="fa-solid fa-download text-indigo-500 px-2 cursor-pointer text-xs"></i>
                    </a>
                    <form method="post" action="<?php echo e(route('archives.delete', [$archive->project_id, $archive->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <button onclick="return confirm('Etes-vous sur de supprimer cette element?')"><i class="fa-solid fa-trash text-red-500 p-1 cursor-pointer text-xs"></i></button>
                    </form>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center">
                <p>This folder is empty</p>
            </div>
            <?php endif; ?>
        </div>

    </div>
</div><?php /**PATH C:\Users\Info-Penguin\Desktop\project-manager-app\resources\views/livewire/archive-folder.blade.php ENDPATH**/ ?>