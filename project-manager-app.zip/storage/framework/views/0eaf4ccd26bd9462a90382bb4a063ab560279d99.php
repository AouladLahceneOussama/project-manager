<div class="flex justify-start items-center space-x-2">
    <input type="text" wire:model="remark" value="<?php echo e($belling->remark); ?>" name="remark" class="text-sm block w-full appearance-none rounded-lg border border-gray-300 bg-white px-3 py-2 font-normal text-gray-700 transition-all focus:border-gray-500 focus:outline-none" placeholder="Remarque" />
    <?php $__errorArgs = ["remark"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs italic"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php if(session()->has('message')): ?> <div class="text-gray-500 font-semibold"><?php echo e(session('message')); ?></div> <?php endif; ?>

    <i wire:click="save" class="fa-solid fa-circle-exclamation text-red-400 cursor-pointer"></i>
</div><?php /**PATH C:\Users\Info-Penguin\Desktop\project-manager-app\resources\views/livewire/remark-input.blade.php ENDPATH**/ ?>