<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Archive')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Button to create a folder -->
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('create-folder', ['projectId' => $id])->html();
} elseif ($_instance->childHasBeenRendered('4n50MTp')) {
    $componentId = $_instance->getRenderedChildComponentId('4n50MTp');
    $componentTag = $_instance->getRenderedChildComponentTagName('4n50MTp');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4n50MTp');
} else {
    $response = \Livewire\Livewire::mount('create-folder', ['projectId' => $id]);
    $html = $response->html();
    $_instance->logRenderedChild('4n50MTp', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


            <!-- Upload file -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mt-6 my-4">
                <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div class="py-5 px-4">
                        <form method="post" action="<?php echo e(route('archives.create', $id)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="project_id" value="<?php echo e($id); ?>">
                            
                            <div class="block uppercase tracking-wide text-gray-500 text-xs font-bold mb-1">
                                <span>File</span>
                            </div>
                            <div class="flex justify-center items-center w-full">
                                <label x-data="{ files: null }" for="dropzone-file" class="flex flex-col justify-center items-center w-full h-42 rounded-lg border-2 border-gray-300 border-dashed cursor-pointer  hover:bg-gray-50 ease-in-out duration-150">
                                    <div class="flex flex-col justify-center items-center pt-5 pb-6">
                                        <svg aria-hidden="true" class="mb-3 w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                                        </svg>
                                        <p class="mb-2 text-sm text-gray-500"><span class="font-semibold">Click to upload your files</span></p>
                                        <p class="text-xs text-gray-500 font-semibold" x-text="files ? files.map(file => file.name).join(', ') : 'PDF, DOCS, JPEG, PNG, JPG...'"></p>
                                    </div>
                                    <input x-on:change="files = Object.values($event.target.files)" name="archive_file" id="dropzone-file" type="file" class="hidden" />
                                </label>
                            </div>
                            <div class="w-full mb-4">
                                <?php $__errorArgs = ['archive_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs italic"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="w-full mb-4">
                                <label class="block uppercase tracking-wide text-gray-500 text-xs font-bold mb-1" for="folder">
                                    Folder
                                </label>
                                <select name="archive_folder" class="text-sm ease-soft block w-full appearance-none rounded-lg border border-solid border-gray-300 bg-white bg-clip-padding px-3 py-2 font-normal text-gray-700 transition-all focus:border-gray-500 focus:outline-none focus:transition-shadow" id="folder">
                                    <option value=""><?php echo e(__('Please pick the folder or Create a new one')); ?></option>

                                    <?php $__currentLoopData = $folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($folder->id); ?>"><?php echo e($folder->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['archive_folder'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs italic"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="w-full">
                                <div class="flex justify-end items-center">
                                    <button class="bg-gray-700 text-white py-2 px-5 rounded-md text-sm cursor-pointer mb-1"><?php echo e(__('Add File')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Folders dragger -->
            <?php $__empty_1 = true; $__currentLoopData = $folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('archive-folder', ['folder' => $folder])->html();
} elseif ($_instance->childHasBeenRendered($folder->id)) {
    $componentId = $_instance->getRenderedChildComponentId($folder->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($folder->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($folder->id);
} else {
    $response = \Livewire\Livewire::mount('archive-folder', ['folder' => $folder]);
    $html = $response->html();
    $_instance->logRenderedChild($folder->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div>
                Add folders first
            </div>
            <?php endif; ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\Info-Penguin\Desktop\project-manager-app\resources\views/archives/index.blade.php ENDPATH**/ ?>