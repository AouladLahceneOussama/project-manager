<img src="{{ Vite::asset('resources/img/logo.jpeg') }}" alt="Logo" class="w-32">
