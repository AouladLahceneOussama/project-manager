<?php return array (
  'category-form' => 'App\\Http\\Livewire\\CategoryForm',
  'category-update' => 'App\\Http\\Livewire\\CategoryUpdate',
  'remark-input' => 'App\\Http\\Livewire\\RemarkInput',
);