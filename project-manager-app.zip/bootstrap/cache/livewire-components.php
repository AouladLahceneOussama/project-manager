<?php return array (
  'archive-folder' => 'App\\Http\\Livewire\\ArchiveFolder',
  'category-form' => 'App\\Http\\Livewire\\CategoryForm',
  'category-update' => 'App\\Http\\Livewire\\CategoryUpdate',
  'create-folder' => 'App\\Http\\Livewire\\CreateFolder',
  'remark-input' => 'App\\Http\\Livewire\\RemarkInput',
);